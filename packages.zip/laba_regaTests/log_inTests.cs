﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using laba_rega;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba_rega.Tests
{
    {
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod]
        public void Login_Successful()
        {
            // Arrange
            log_in form = new log_in();
            form.text_box_login_TextChanged.Text = "admin";// ввод логина
            form.ttextBoxpassword.Text = "1234";// ввод пароля

            // Act
            form.button2_Click(null, null);

            // Assert
            end form2 = (end)form.OwnedForms[0];
            Assert.IsNotNull(form2, "Form2 is not opened.");
            Assert.IsTrue(form2.Visible, "Form2 is not visible.");
        }
    }
    public class Form3Tests1
    {
        [TestMethod]
        public void TestCheckUser()
        {
            // Arrange
            sign_up form = new sign_up();
            form.ttextBoxlogin.Text = "TestUser";
            form.ttextBoxpassword.Text = "TestPassword";

            // Act
            bool result = form.checkuser();

            // Assert
            Assert.IsTrue(result, "User should exist in database");
        }
    }
    public class Form3Tests2
    {
        [TestMethod]
        public void TestButtonClick()
        {
            // Arrange
            sign_up form = new sign_up();
            form.ttextBoxlogin.Text = "TestUser";
            form.ttextBoxpassword.Text = "TestPassword";

            // Act
            form.button2_Click(null, null);

            // Assert
            Assert.IsTrue(form.Visible == false, "Form should be hidden");
        }
    }

    public class Form3Tests3
    {
        [TestMethod]
        public void TestForm3Load()
        {
            // Arrange
            var form3 = new sign_up();

            // Act
            form3.sign_up_Load(null, EventArgs.Empty);

            // Assert
            Assert.AreEqual('*', form3.ttextBoxpassword.PasswordChar);
            Assert.AreEqual(50, form3.ttextBoxlogin.MaxLength);
            Assert.AreEqual(50, form3.ttextBoxpassword.MaxLength);
        }

    }

    public class Form5Tests
    {
        [TestMethod]
        public void Button1Click_AddsNewPcRecordWhenNomerIsNumeric()
        {
            // Arrange
            Add_Form form5 = new Add_Form();
            form5.textBox_name1.Text = "PC1";
            form5.textBox_type1.Text = "Desktop";
            form5.textBox_nomer1.Text = "123";

            // Act
            form5.button1_Click(null, null);

            // Assert
            // TODO: Verify that a new PC record with the specified values was added to the database
        }

        [TestMethod]
        public void Button1Click_ShowsWarningMessageWhenNomerIsNotNumeric()
        {
            // Arrange
            Add_Form form5 = new Add_Form();
            form5.textBox_name1.Text = "PC1";
            form5.textBox_type1.Text = "Desktop";
            form5.textBox_nomer1.Text = "abc";
            string expectedMessage = "Номер должна иметь числовой формат";

            // Act
            form5.button1_Click(null, null);

            // Assert

        }
    }
}

