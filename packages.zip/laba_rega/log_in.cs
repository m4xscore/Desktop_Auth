﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace laba_rega
{
    public partial class log_in : Form
    {
        DataBase dataBase = new DataBase();
        public log_in()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            textBox1.UseSystemPasswordChar = true;
        }
        public void log_in_Load_1(object sender, EventArgs e)
        {
            text_box_login.MaxLength = 50;
            textBox1.MaxLength = 50;
        }

        public void button1_Click(object sender, EventArgs e)
        {
            var loginUser = text_box_login.Text;
            var passUser = textBox1.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"select id_user, login_user, password_user from log_in where login_user = '{loginUser}' and password_user = '{passUser}'";

            SqlCommand command = new SqlCommand(querystring, dataBase.GetConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if(table.Rows.Count == 1)
            {
                MessageBox.Show("Вы успешно вошли !", "Успешно !", MessageBoxButtons.OK, MessageBoxIcon.Information);
                end frm1 = new end();
                this.Hide();
                frm1.Show();
            }
            else
                MessageBox.Show("Такого аккаунта не существует !", "Аккаунта не существует !!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            sign_up frm_sign = new sign_up();
            frm_sign.Show();
            this.Hide();
        }

        public void CheckPass_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckPass.Checked)
            {
                textBox1.UseSystemPasswordChar = false;
            }
            else
            {
                textBox1.UseSystemPasswordChar = true;
            }
        }

        public void pictureClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            text_box_login.Text = "";
        }

        public void text_box_login_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
