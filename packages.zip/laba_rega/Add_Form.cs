﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace laba_rega
{
    public partial class Add_Form : Form
    {
        DataBase dataBase = new DataBase();
        public Add_Form()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void button_safe_Click(object sender, EventArgs e)
        {
            dataBase.openConnection();
           
            var Name = textBox_Name.Text;
            var Type = textBox_Type.Text;
            var Reg = textBox_Reg.Text;

            {
                var addQuery = $"insert into info (name_package, type_package, reg_number_package) values ('{Name}','{Type}','{Reg}')";

                var command = new SqlCommand(addQuery, dataBase.GetConnection());
                command.ExecuteNonQuery();

                MessageBox.Show("Запись успешно создана!!", "Успех !!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
            dataBase.closeConnection();
            end Add_Form = new end();
            this.Hide();
            Add_Form.Show();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
