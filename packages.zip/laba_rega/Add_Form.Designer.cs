﻿namespace laba_rega
{
    partial class Add_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Form));
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_Name = new System.Windows.Forms.TextBox();
            this.textBox_Type = new System.Windows.Forms.TextBox();
            this.textBox_Reg = new System.Windows.Forms.TextBox();
            this.label_type = new System.Windows.Forms.Label();
            this.label_count = new System.Windows.Forms.Label();
            this.label_postavshik = new System.Windows.Forms.Label();
            this.button_safe = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(180, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Создание записи";
            // 
            // textBox_Name
            // 
            this.textBox_Name.Location = new System.Drawing.Point(170, 177);
            this.textBox_Name.Multiline = true;
            this.textBox_Name.Name = "textBox_Name";
            this.textBox_Name.Size = new System.Drawing.Size(203, 27);
            this.textBox_Name.TabIndex = 2;
            // 
            // textBox_Type
            // 
            this.textBox_Type.Location = new System.Drawing.Point(170, 214);
            this.textBox_Type.Multiline = true;
            this.textBox_Type.Name = "textBox_Type";
            this.textBox_Type.Size = new System.Drawing.Size(203, 27);
            this.textBox_Type.TabIndex = 3;
            // 
            // textBox_Reg
            // 
            this.textBox_Reg.Location = new System.Drawing.Point(170, 254);
            this.textBox_Reg.Multiline = true;
            this.textBox_Reg.Name = "textBox_Reg";
            this.textBox_Reg.Size = new System.Drawing.Size(203, 27);
            this.textBox_Reg.TabIndex = 4;
            // 
            // label_type
            // 
            this.label_type.AutoSize = true;
            this.label_type.Location = new System.Drawing.Point(23, 190);
            this.label_type.Name = "label_type";
            this.label_type.Size = new System.Drawing.Size(67, 13);
            this.label_type.TabIndex = 6;
            this.label_type.Text = "Имя товара";
            // 
            // label_count
            // 
            this.label_count.AutoSize = true;
            this.label_count.Location = new System.Drawing.Point(23, 227);
            this.label_count.Name = "label_count";
            this.label_count.Size = new System.Drawing.Size(64, 13);
            this.label_count.TabIndex = 7;
            this.label_count.Text = "Тип товара";
            // 
            // label_postavshik
            // 
            this.label_postavshik.AutoSize = true;
            this.label_postavshik.Location = new System.Drawing.Point(23, 267);
            this.label_postavshik.Name = "label_postavshik";
            this.label_postavshik.Size = new System.Drawing.Size(133, 13);
            this.label_postavshik.TabIndex = 8;
            this.label_postavshik.Text = "Регистрационный номер";
            // 
            // button_safe
            // 
            this.button_safe.Location = new System.Drawing.Point(216, 316);
            this.button_safe.Name = "button_safe";
            this.button_safe.Size = new System.Drawing.Size(111, 42);
            this.button_safe.TabIndex = 10;
            this.button_safe.Text = "Сохранить";
            this.button_safe.UseVisualStyleBackColor = true;
            this.button_safe.Click += new System.EventHandler(this.button_safe_Click);
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.listView1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(148, 98);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(240, 56);
            this.listView1.TabIndex = 12;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(421, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(122, 122);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // Add_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_safe);
            this.Controls.Add(this.label_postavshik);
            this.Controls.Add(this.label_count);
            this.Controls.Add(this.label_type);
            this.Controls.Add(this.textBox_Reg);
            this.Controls.Add(this.textBox_Type);
            this.Controls.Add(this.textBox_Name);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Name = "Add_Form";
            this.Text = "Add_Form";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_Name;
        private System.Windows.Forms.TextBox textBox_Type;
        private System.Windows.Forms.TextBox textBox_Reg;
        private System.Windows.Forms.Label label_type;
        private System.Windows.Forms.Label label_count;
        private System.Windows.Forms.Label label_postavshik;
        private System.Windows.Forms.Button button_safe;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}