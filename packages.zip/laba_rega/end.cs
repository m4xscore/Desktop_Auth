﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace laba_rega
{   
    enum RowState
    {
        Existed,
        New,
        Modifiled,
        ModifiledNew,
        Delete
    }
    public partial class end : Form
    {
        DataBase dataBase = new DataBase();
        int SelectedRow;
        public end()
        {
            InitializeComponent();
        }
        private void CreateColumns()
        {
            dataGridView1.Columns.Add("Id", "id_package");
            dataGridView1.Columns.Add("Name", "name_package");
            dataGridView1.Columns.Add("Type", "type_package");
            dataGridView1.Columns.Add("Reg", "reg_number_package");
            dataGridView1.Columns.Add("IsNew", string.Empty);
        }
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), RowState.ModifiledNew);
        }
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string queryString = $"select * from Info";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();
            while(reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        private void end_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridView1);
        }
        
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridView1);
        }

        private void button_new_Click(object sender, EventArgs e)
        {
            Add_Form addFrm = new Add_Form();
            this.Hide();
            addFrm.Show();
        }

        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchstring = $"select * from info where concat (id_package, name_package, type_package, reg_number_package) like '%" + textBox_search.Text + "%'";
            SqlCommand com = new SqlCommand(searchstring, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();
            while(read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }

        private void textBox_search_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridView1);
        }

        private void deleteRow()
        {
            int index = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows[index].Visible = false;

            if (dataGridView1.Rows[index].Cells[0].Value.ToString() == string.Empty)
            {
                dataGridView1.Rows[index].Cells[4].Value = RowState.Delete;
                return;
            }
            dataGridView1.Rows[index].Cells[4].Value = RowState.Delete;
        }

        private void Update()
        {
            dataBase.openConnection();
            for(int index = 0; index < dataGridView1.Rows.Count; index++)
            {
                var rowState = (RowState)dataGridView1.Rows[index].Cells[4].Value;
                if (rowState == RowState.Existed)
                    continue;
                if(rowState == RowState.Delete)
                {
                    var id = Convert.ToInt32 (dataGridView1.Rows[index].Cells[0].Value);
                    var deleteQuery = $"delete from info where id_package = {id}";

                    var command = new SqlCommand(deleteQuery, dataBase.GetConnection());
                    command.ExecuteNonQuery();
                }
            }
            dataBase.closeConnection();
        }

        private void button_del_Click(object sender, EventArgs e)
        {
            deleteRow();
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            Update();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            log_in end = new log_in();
            this.Hide();
            end.Show();
        }
    }
}